import time
from importlib import reload

import utilities

reload(utilities.browser_utils)
reload(utilities.config_utils)
reload(utilities.data_utils)
reload(utilities.screenshot_utils)
reload(utilities.driver_utils)

