
function git_User_Data() {

  myvar=$1
  my_file=./data/git-repo.dat

  i=-1
  declare -A my_data;
  #declare -p my_data;

  while IFS= read -r line; do
    # echo $line
    i=$(expr $i + 1)
    # echo $i
    my_data[$i]="${line}"
  done < $my_file

  #mylen=$i
  # echo $mylen
  #for (( i=0; i<=mylen; i++ )); do
  #  #echo $i
  #  echo ${my_data[$i]}
  #done

  #git_User_Data=${my_data[0]};

  #return $(my_data);
  echo "${my_data[$myvar]}";
}


