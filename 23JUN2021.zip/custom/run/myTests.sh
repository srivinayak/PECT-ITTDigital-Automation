cd ..

cd venv/Scripts

source ./activate

cd ../../

export BROWSERSTACK_USERNAME=vinaysrinivasan2
export BROWSERSTACK_ACCESS_KEY=ryyF3o417XFGPFqrxwpA

python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc001" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc002" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc003" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc004" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc005" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc006" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc007" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc008" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc009" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc010" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc011" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc012" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc013" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc014" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc015" --html=report.html --self-contained-html
python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_browserstack_chrome.json --variables i18n.json --variables variables.json --tags "pect_tc016" --html=report.html --self-contained-html
