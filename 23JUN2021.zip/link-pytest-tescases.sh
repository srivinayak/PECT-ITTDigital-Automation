DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

source "$DIR/etc/utils/getGitData.sh"

myvar=$(git_User_Data 3);

source "$DIR/etc/utils/getSplitData.sh"

WorkingDir=$(SplitData ${myvar})

WorkingDir="$DIR/$WorkingDir"

testsDir="$WorkingDir/tests-ui"

runDir="$testsDir/run"

logsDir="$testsDir/logs"

if [ ! -d "${logsDir}" ]; then
    mkdir "${logsDir}"
fi

myTestsUI_Custom_Content="$DIR/custom/"
myTestUI_Contents_to_be_Replaced="$testsDir/"

cp -TRv $myTestsUI_Custom_Content $myTestUI_Contents_to_be_Replaced
