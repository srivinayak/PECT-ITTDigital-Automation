
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

myGitClone="git-clone.sh"

cd etc

./${myGitClone}

sleep 5
cd ../

my_python=$(python -c "import sys; print('.'.join(map(str, sys.version_info[0:2])))")
echo $my_python

if [ $my_python == 3.9 ]; then
    echo "You Have the Latest Version of Python"
else
  #DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
  source "$DIR/etc/utils/getPythonData.sh"

  myPythonDownloadData0=$(getMyPythonData 0)
  myPythonDownloadData1=$(getMyPythonData 2)
  myPythonDownloadData2=$(getMyPythonData 3)

  source "$DIR/etc/utils/getSplitData.sh"

  my_os=$(SplitData "$myPythonDownloadData0")

  myURL=$(SplitData "$myPythonDownloadData1")

  myPython=$(SplitData "$myPythonDownloadData2")

  case $my_os in
    WINDOWS*)
      source "$DIR/etc/utils/win/install-python.sh"
      myval=$(myinstall $myURL $myPython)
      ${myval}
      install_venv="$DIR/etc/utils/win/install-venv.sh"
      myvenv="$DIR/etc/utils/win/my-venv.sh"

      myTest="$DIR/etc/utils/win/myTest.sh"
      ;;
    OSX*)
      source "$DIR/etc/utils/osx/install-python.sh"
      myval=$(myinstall $myURL $myPython)
      ${myval}
      install_venv="$DIR/etc/utils/osx/install-venv.sh"
      myvenv="$DIR/etc/utils/osx/my-venv.sh"
      ;;
    UBUNTU*)
      source "$DIR/etc/utils/ubuntu/install-python.sh"
      myval=$(myinstall $myURL $myPython)
      ${myval}
      install_venv="$DIR/etc/utils/ubuntu/install-venv.sh"
      myvenv="$DIR/etc/utils/ubuntu/my-venv.sh"
      ;;
  esac

fi

source "$DIR/etc/utils/getGitData.sh"

myvar=$(git_User_Data 3);

source "$DIR/etc/utils/getSplitData.sh"

WorkingDir=$(SplitData ${myvar})

WorkingDir="$DIR/$WorkingDir"

testsDir="$WorkingDir/tests-ui"

logsDir="$testsDir/logs"

install="install.sh"
#run="run_tests.sh"


cd $testsDir

#case $my_os in
#WINDOWS*)
  cat $install_venv > "install-venv.sh"
  cat $myvenv > "myvenv.sh"
  ./install-venv.sh
  ./myvenv.sh

  sleep 3
  cd "venv"
  cd "Scripts"

  source ./activate
  #./activate

  cd ../../
  runDir="run"
  if [ ! -d ${runDir} ]; then
    mkdir $runDir
  fi
  cd run

  myTestsUI_Install="$DIR/custom/run/install.sh"
  myOldTestsUI_Install="$testsDir/install.sh"
  cat "${myTestsUI_Install}" > "${myOldTestsUI_Install}"

  mynewTest="myTest.sh"
  cat $myTest > $mynewTest
  cd ../

  sleep 5

#  ;;
#esac



if [ ! -d "${logsDir}" ]; then

  mkdir "${logsDir}"

fi


./${install}
#./${run}

gitDir=".git"
gitHubDir=".github"

cd $WorkingDir

if [ -d $gitHubDir ]; then
  rm -rf $gitHubDir
fi

if [ -d $gitDir ]; then
    rm -rf $gitDir
fi

cd $testsDir

cd run
./${mynewTest}
