# OSS-Pytest-Plugin

First Please Populate:

/etc/data/git-repo.data



Second Please Verify:

/etc/data/python-xxxxx-set-up.dat for data correctness

Also please verify custom folder data



Third:

Install git-bash incase of WINDOWS

In case of MAC OSX use BASH Shell

In case of LINUX UBUNTU use BASH Shell



Fourth:

Elevated Admin Rights are required in case of WINDOWS

Elevated root user rights are required in case of MAC OSX

Elevated root user or sudo user rights are required in case of LINUX UBUNTU



Fifth:

Use install-pytest-framework.sh to install the pytest-framework

Use link-pytest-tescases.sh to link the custom test cases

Use run-test-cases.sh shell script to mock the TestSuite


