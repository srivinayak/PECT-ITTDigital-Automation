
declare -A myvar

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

source "$DIR/utils/getGitData.sh"

for (( i = 0; i < 5; i++ )); do
    myvar[$i]=$(git_User_Data $i);
    #echo ${myvar[$i]}
done

source "$DIR/utils/getSplitData.sh"

myGITuser=$(SplitData ${myvar[0]})

myGITpassword=$(SplitData ${myvar[1]})

myGIT_remote_repository=$(SplitData ${myvar[2]})

myLocalCloneRepositoryPath=$(SplitData ${myvar[3]})

myGIT_remote_branch=$(SplitData ${myvar[4]})

cd ../

if [ "${myGITpassword}" == "password" ];
then
  myGITrepository="https://${myGITuser}${myGIT_remote_repository}";
else
  myGITrepository="https://""${myGITuser}"":""${myGITpassword}${myGIT_remote_repository}";
fi

if [ ! -d "${myLocalCloneRepositoryPath}" ];
then
  mkdir "${myLocalCloneRepositoryPath}"
  echo "${myLocalCloneRepositoryPath} has been created"
  echo "Cloning ${myGITrepository} to ${myLocalCloneRepositoryPath}"
  git clone -b "${myGIT_remote_branch}"  "${myGITrepository}" "${myLocalCloneRepositoryPath}"

else
  echo "${myLocalCloneRepositoryPath} exists"
fi
