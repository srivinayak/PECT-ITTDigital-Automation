
function SplitData() {


  myvar=$1;
  IFS='='
  read -a myStrArray <<< ${myvar};
  i=0;
  for val in "${myStrArray[@]}"; do
    i=$(expr $i + 1);
    #echo ${i}
    #echo ${val}
  done
  echo $val
  #return ${myStrArray[$i]};
}
