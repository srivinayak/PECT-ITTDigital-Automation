
function myinstall() {

  myURL=$1

  myPython=$2

  DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
  local="$DIR/local"
  myPython="$local/$myPython"

  myPythonDownload="curl -o $myPython $myURL"

  mycomment='Just for me, no test suite.'
  install="$myPython /quiet InstallAllUsers=0 Include_launcher=0 Include_test=0 SimpleInstall=1 SimpleInstallDescription=$mycomment"

  if [ ! -d "$local" ];
  then
    mkdir "$local"
    cd $local
    #echo "local directory has been created"
    #echo "downloading python to local directory"
    ${myPythonDownload}
    sleep 10
    #${install}
  else
    #echo "$local folder exists"
    cd $local
    if [ ! -f ${myPython} ]; then
        ${myPythonDownload}
        sleep 10
        #${install}
    #else
      #echo "$myPython exists"
    fi
  fi
  echo "${install}"
}
