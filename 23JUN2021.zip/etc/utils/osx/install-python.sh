
function myinstall() {

  myURL=$1

  myPython=$2

  DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
  local="$DIR/local"
  myPython="$local/$myPython"

  myPythonDownload="curl -o $myPython $myURL"

  install="installer -pkg $myPython -target CurrentUserHomeDirectory"

  if [ ! -d "$local" ];
  then
    mkdir "$local"
    cd $local
    ${myPythonDownload}
    sleep 10
  else
    cd $local
    if [ ! -f ${myPython} ]; then
        ${myPythonDownload}
        sleep 10
    fi
  fi
  echo "${install}"
}
