
function gitUserDataAsArray() {

  my_file=./etc/data/git-repo.dat

  i=-1
  declare -A my_data;
  #declare -p my_data_params;

  while IFS= read -r line; do
    # echo $line
    i=$(expr $i + 1)
    # echo $i
    my_data[$i]=${line}
  done < $my_file

  my_data_params=$(declare -p my_data);

  #  for (( i = 0; i < 3; i++ )); do
  #    my_data_params[$i]=${my_data[$i]};
  #  done

    return "${my_data_params}"
    #return $(my_data);
}

#gitUserDataAsArray
