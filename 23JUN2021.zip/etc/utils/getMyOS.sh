

function myOScheck() {

  declare -A myvar

  DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

  source "$DIR/os-check.sh"

  myvar[0]=$(myOS)
  echo ${myvar[0]}

}

