


function getMyPythonData() {

  myvar=$1
  DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
  source "$DIR/getMyOS.sh"
  my_OS=$(myOScheck)

  myPythonDataFile=""

  case $my_OS in
    WINDOWS*) myPythonDataFile="$DIR/../../etc/data/python-win-set-up.dat" ;;
    OSX*)     myPythonDataFile="$DIR/../../etc/data/python-mac-set-up.dat" ;;
    LINUX*)   myPythonDataFile="$DIR/../../etc/data/python-linux-set-up.dat" ;;
  esac

  i=-1
  declare -A my_data;

  while IFS= read -r line; do
    # echo $line
    i=$(expr $i + 1)
    # echo $i
    my_data[$i]="${line}"
  done < $myPythonDataFile

  echo "${my_data[$myvar]}";

}


