cd ..

export BROWSERSTACK_USERNAME=vinaysrinivasan2
export BROWSERSTACK_ACCESS_KEY=ryyF3o417XFGPFqrxwpA

python -m pytest -v --driver Browserstack --capability headless true --variables webdriver/capabilities_web.json --variables i18n.json --variables variables.json --tags "pect_tc016" --html=report.html --self-contained-html
