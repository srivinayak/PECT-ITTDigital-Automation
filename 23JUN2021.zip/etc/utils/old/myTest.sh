cd ..

declare -A myvar

source ./utils/getGitData.sh

for (( i = 0; i < 4; i++ )); do
    myvar[$i]=$(git_User_Data $i);
    echo ${myvar[$i]}
done

myvar[0]=$(git_User_Data 0);
myvar[1]=$(git_User_Data 1);
myvar[2]=$(git_User_Data 2);
##echo ${myvar[2]};

##IFS='='
##read -a myStrArray <<< ${myvar[0]}

##for val in "${myStrArray[@]}"; do
  ##echo ${val}
##done


##source ./utils/getDataAsArray.sh
#echo ${myvar[0]}
##myvar=$(gitUserDataAsArray)
#echo ${myvar[0], myvar[1], myvar[2]}

##echo $myvar

##var1=$(declare -p myvar)
##echo ${myvar[0]}

source ./utils/getSplitData.sh

myval=$(SplitData ${myvar[3]})
echo ${myval}
echo ${myval}
