
function myinstall() {

  myURL=$1

  myPython=$2

  DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
  local="$DIR/local"
  myPython="$local/$myPython"

  myPythonDownload="curl -o $myPython $myURL"

  install1="tar xf Python-3.9.5.tgz --directory $local"
  install2="sudo ./configure --enable-optimizations"
  install="sudo make altinstall"

  if [ ! -d "$local" ];
  then
    mkdir "$local"
    #cd $local
    ${myPythonDownload}
    sleep 10
    ${install1}
    cd $local
    cd *
    ${install2}
  else
    cd $local
    if [ ! -f ${myPython} ]; then
        ${myPythonDownload}
        sleep 10
        ${install1}
        cd $local
        cd *
        ${install2}
    fi
  fi
  myupdate="sudo apt update"
  mycommon="sudo apt install software-properties-common"
  deadsnake="sudo add-apt-repository ppa:deadsnakes/ppa"
  mypython3="sudo apt install python3.9"
  buildessentials="sudo apt install build-essential zlib1g-dev libncurses5-dev libgdbm-dev libnss3-dev libssl-dev libreadline-dev libffi-dev wget"
  ${myupdate}
  ${mycommon}
  ${deadsnake}
  ${buildessentials}
  ${myupdate}
  install0="$mypython3"
  echo "${install0}"
}
