user=VinayS777
password_token=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
repo=@github.com/pfizer/python-test-automation-boilerplate.git
localrepo=WorkingDir
remotebranch=release/2.2

user=VinayS777
password_token=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
repo=@github.com/pfizer/PECT-TestAutomation.git
localrepo=WorkingDir
remotebranch=main
