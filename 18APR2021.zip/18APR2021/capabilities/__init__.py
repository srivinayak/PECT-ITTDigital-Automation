__all__ = [
    "remote_capabilities.py"
]

from importlib import reload

from capabilities import (
    remote_capabilities
)

reload(remote_capabilities)
